# suven-projects.github.io
under the internship program of suven consultants and technology , I completed the assigned projects in due time .


          #INTERNSHIP PROGRAM :-  UI/UX (Html5 + CSS3) Coding Internship {2 Weeks (70 hrs)}

Here you can see glimpses of one of my project :)

MAIN PAGE:
![g1](https://user-images.githubusercontent.com/73931975/105002907-fb515c80-5a57-11eb-99d4-f7300cc2967f.png)

GALLERY OF MEMORIES:
![g3](https://user-images.githubusercontent.com/73931975/105002937-02786a80-5a58-11eb-95e6-ffa85c1faa8b.png)

 PROFILE CARDS:
![g4](https://user-images.githubusercontent.com/73931975/105002943-060bf180-5a58-11eb-9662-ff125eeef39e.png)

JUST A HELLO:
![g2](https://user-images.githubusercontent.com/73931975/105002945-060bf180-5a58-11eb-99ac-c259da9b81ac.png)
 
                :)
  
